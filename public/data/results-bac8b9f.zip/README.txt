VIOBench Results release — 6 September 2026
Source revision: bac8b9feb05c93a1d33b5fec08259730517965ee

accuracy.json: canonical ATE summary and sequence contribution ledger.
The protocol is epa-drift valid, verification candidate. n and N_report
refer to finite values and report sequence headers, not successful runs.

 efficiency.json: all 164 actual resource-table rows, including primary
and extended metrics with missing states and source selected-run counts.
Native timing is implementation-specific. Within-run SD is not between-run uncertainty.

source-tables.json: all 157 original Final dataset tables, preserving
separate protocol headings, method labels, source averages and cell strings.
SR is not expanded; no RPE pair units/order are newly inferred.

results-manifest.json: checksums for these public JSON exports.

No estimators or trajectory evaluators were rerun for this website release.
No private source documents, raw run logs, or execution environments are included.
See https://vio-bench.github.io/benchmark/protocol/ for definitions.
